package com.example.zookeeper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@EnableDiscoveryClient
@RestController
@EnableConfigurationProperties
public class ZookeeperApplication {

	@Autowired
	private LoadBalancerClient loadBalancer;

	@Autowired
	private DiscoveryClient discovery;

	@Value("${spring.application.name}")
	private String instanceName;

	@RequestMapping("/discovery")
	public Object discovery() {
		System.out.println(loadBalancer.choose("tomcat"));
		return "discovery";
	}

	@RequestMapping("/all")
	public List<String> all() {
		System.out.println(discovery.getServices());
		return discovery.getServices();
	}

	@GetMapping("/services")
	public List<String> serviceUrl() {
		List<ServiceInstance> list = discovery.getInstances(instanceName);
		List<String> services = new ArrayList<>();
		if (list != null && list.size() > 0 ) {
			list.forEach(serviceInstance -> {
				services.add(serviceInstance.getUri().toString());
				System.out.println("****"+serviceInstance.getUri().toString());
			});
		}
		return services;
	}


	public static void main(String[] args) {
		SpringApplication.run(ZookeeperApplication.class, args);
	}



}
